#ifndef USER_H
#define USER_H

#endif // USER_H
#pragma once
#include <string>
using namespace std;

class User{
public:
    int score;//当前分
    int level;//关卡数
    int purpose;//目标分



    User(){

    }


};
