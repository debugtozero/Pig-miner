#include "clawline.h"



    Clawline::Clawline(GameMainWindow *parent){

    }



