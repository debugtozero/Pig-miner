#ifndef CLAWLINE_H
#define CLAWLINE_H

#include <QMainWindow>
//引入定时器头文件
#include <QWidget>
#include <QTimer>
#include <QLabel>
#include <gamemainwindow.h>
#include <QPainter>



class Clawline: public QWidget
{
public:
     Clawline(GameMainWindow *parent = nullptr);
    ~Clawline();


public:
    void paintEvent(QPaintEvent *event)
    {
        Q_UNUSED(event);

        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);
        // 绘制线
        painter.setPen(Qt::black);
        painter.drawLine(50, 150, 200, 150);
    }
};

#endif // CLAWLINE_H
