#include "gamemainwindow.h"
#include "ui_gamemainwindow.h"
#include "mainwindow.h"
#include "winmainwindow.h"
#include "losemainwindow.h"
#include "shopmainwindow.h"
#include <QLabel>
#include <QMovie>
#include "userservice.h"
#include <QTimer>
#include <hook.h>
#include<QPaintEvent>
#include <QPen>
#include "hook.h"
#include <QWidget>
#include"line.h"
#include <math.h>
#include<QDebug>
#include "store.h"
int level=1;
int now_score = 0;
//QLabel *hook = new QLabel();
int stone[6]={0,1,3,3,4,5};
int gold[6]={0,3,5,5,6,7};

double place_y[10]={250,300,350,400,450,500,550,600,650,700};
double place_x[10]={200,300,400,500,550,600,650,700,800,900};
vector <int> placex;
vector <int> placey;
vector<store*> users;
int stone_length = stone[level];
int which=0;
store *hook;

GameMainWindow::GameMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::GameMainWindow)
{

    ui->setupUi(this);
    QPalette pa(this->palette());
//    :/game_back.jpg
    QImage img = QImage(":/game_back.jpg");
    img = img.scaled(this->size());
    QBrush *pic = new QBrush(img);
    pa.setBrush(QPalette::Window,*pic);
    this->setAutoFillBackground(true);
    this->setPalette(pa);

//    setMaximumSize(688,532);
//    setMinimumSize(688,532);

//    //设置动画播放效果
    QLabel *label = new QLabel();
    QMovie *movie = new QMovie(":/mineral/IMG_5124.gif");
    label->setMovie(movie);
    movie->start();
    label->setGeometry(width()/2-80,0,150,150);
    label->setStyleSheet("");
    label->setVisible(true);
    label->setParent(this);
    label->setStyleSheet("QLabel{background-image: url(:/worker.png);}");
    timelabel =new QLabel("60",this);
    QFont font =timelabel->font();
    font.setPointSize(20);
    timelabel->setFont(font);
    timelabel->setGeometry(width()-50,-10,100,100);

    gametime =new QTimer(this);
    gametime->start(1000);
    connect(gametime,&QTimer::timeout,this,&GameMainWindow::game_CountDown);//绑定定时器信号与槽函数
    Userservice service;
    QLabel *level_window = new QLabel();
    QFont ft;
    ft.setPointSize(20);
    level_window->setFont(ft);
    level_window->setText(QString::number(level));
    level_window->setParent(this);
    level_window->setVisible(true);
    level_window->setGeometry(width()-90,50,100,100);
    level_window->show();//关卡加载

    int goals[6]={0,600,1500,3000,5000,8000};
    QLabel *score_window = new QLabel();
    QFont st;
    ft.setPointSize(20);
    score_window->setFont(ft);
    score_window->setText(QString::number(goals[level]));
    score_window->setParent(this);
    score_window->setVisible(true);
    score_window->setGeometry(150,60,100,100);
    score_window->show();//关卡加载



    //    hook->setStyleSheet("border-image: url(:/hook.png);");
//    hook->setParent(this);
//    hook->setMaximumSize(100,100);




//钩子倒计时
    hooktime= new QTimer(this);
    hooktime->start(10);
    time =10000000;
//timelabel =new QLabel("60",this);
//                hook->setGeometry(endx,endy,100,100);
connect(hooktime,&QTimer::timeout,this,&GameMainWindow::hook_CountDown);
//链接钩子倒计时定时器
//链接倒计时和重绘事件
connect(hooktime, SIGNAL(timeout()), this, SLOT(animate()));
//mousePressEvent();

for(int i=0;i<gold[level];i++){
        store *s=new store();
        s->exsit=true;
        s->exsit_2=false;
            s->is_exist_worth=true;
        s->worth=300;
        users.push_back(s);
        s->setStyleSheet("border-image: url(:/mineral/Small_gold.png);");
        s->setParent(this);
        s->setMaximumSize(100,100);
        s->place_x=place_x[(int)(qrand()%10)];
        s->place_y=place_y[(int)(qrand()%10)];

        s->move(s->place_x,s->place_y);
        placex.push_back(s->place_x);
        placey.push_back(s->place_y);
        s->show();

//        for(int i=0;i<stone_length;i++){

//        }
}

for(int i=0;i<stone[level];i++){
    store *s=new store();
    s->exsit=true;
    s->exsit_2=false;
    s->is_exist_worth=true;
    s->worth=10;
    users.push_back(s);
        s->setStyleSheet("border-image: url(:/mineral/stone.png);");
        s->setParent(this);
        s->setMaximumSize(100,100);

        s->place_x=place_x[(int)(qrand()%10)];
        s->place_y=place_y[(int)(qrand()%10)];

        s->move(s->place_x,s->place_y);
        placex.push_back(s->place_x);
        placey.push_back(s->place_y);
        s->show();
//        for(int i=0;i<stone_length;i++){


//        }

}


//for(int i=0;i<placex.size();i++){

//        if(users[i]->exsit==false&&users[i]->is_exist_worth==true){
//         now_score=now_score+users[i]->exsit;
//         users[i]->is_exist_worth=false;
//         qDebug()<<now_score;



//    }
//}

//for(int i=0, j=0;i<placex.size();i++,j++){
//qDebug()<<placex[i]<<
//        if(endx>placex[i]&&endx<=(placex[i]+100)&&endy>placey[i]&&endy<=placey[i]){
//            qDebug()<<"抓到了";


//    }
//}
 now_score_label = new QLabel("0",this);



}

GameMainWindow::~GameMainWindow()
{
    delete ui;
}


void GameMainWindow::on_pushButton_clicked()
{
    MainWindow *mainwindow = new MainWindow();
    mainwindow->show();
    close();
}

void GameMainWindow::on_pushButton_2_clicked()
{
    winMainWindow *winmainwindow = new winMainWindow();
    winmainwindow->show();



    shopMainWindow *shopmainwindow = new shopMainWindow();
    shopmainwindow->show();
}

void GameMainWindow::game_CountDown()
{
    int i = timelabel->text().toInt();

    if(i>0){
    i =i-1;
    timelabel->setText(QString::number(i));


    bool is_exist_nextgame=true;
    for(int i=0, j=0;i<placex.size();i++,j++){

            if(users[i]->exsit==true){
//                qDebug()<<"还有矿物存在";
                is_exist_nextgame=false;


        }

    }
    if(is_exist_nextgame==true){
        level++;
        gametime->stop();
        winMainWindow *winmainwindow = new winMainWindow();
        winmainwindow->show();
        close();
    }
    }
    else{
        Userservice service;
        if(service.if_score_achieve(now_score,level)){
            level++;
            gametime->stop();
            winMainWindow *winmainwindow = new winMainWindow();
            winmainwindow->show();
            close();

        }else{
            gametime->stop();
            loseMainWindow *losemainwindow = new loseMainWindow();
            losemainwindow->show();
            close();
        }


    }

}
void GameMainWindow::animate()
{
    endx=x+len*cos(angle*3.1415);
    endy=y+len*sin(angle*3.1415);
//    hook->move(endx,endy);

    logic();
    repaint();

}

void GameMainWindow::hook_CountDown()
{

        score_update();
    if(time>0){
        time =time-1;
    }
    else{
        hooktime->stop();


    }

}
void GameMainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
       QPen pen;
       QRect target(endx*0.82,endy*0.92,endx,endy);
       QRect source(0,0,198,198);
       QImage image(":/hook(1)(1).png");
    switch (state) {
   case 0:



//        qDebug()<<endx;
//         qDebug()<<endy;
        angle=angle+0.005*dir;
        if(angle>=0.95){
            dir=-1;
        }else if(angle<0.05){
            dir=1;
        }

//        painter.translate(350,120-20);

        pen.setWidth(6);
        painter.setPen(pen);
        painter.setRenderHint(QPainter::Antialiasing,true);
        painter.drawLine(x,y,endx,endy);

        painter.drawImage(target,image,source);
        break;
    case 1:
        if(len<800){

            len=len+10;

//            qDebug()<<endx;
//             qDebug()<<endy;
//            angle=angle+0.005*dir;
//            if(angle>=0.95){
//                dir=-1;
//            }else if(angle<0.05){
//                dir=1;
//            }

    //        painter.translate(350,120-20);

            pen.setWidth(6);
            painter.setPen(pen);
            painter.setRenderHint(QPainter::Antialiasing,true);
            painter.drawLine(x,y,endx,endy);
             painter.drawImage(target,image,source);


        }else{
                state=2;
        }
        break;
    case 2:
        if(len>=50){
        len=len-5;


//            qDebug()<<endx;
//             qDebug()<<endy;
//        angle=angle+0.005*dir;
//        if(angle>=0.95){
//            dir=-1;
//        }else if(angle<0.05){
//            dir=1;
//        }


//        painter.translate(350,120-20);

        pen.setWidth(6);
        painter.setPen(pen);
        painter.setRenderHint(QPainter::Antialiasing,true);
        painter.drawLine(x,y,endx,endy);
         painter.drawImage(target,image,source);

        }else{
            state=0;

        }
    case 3:
        if(len>50){
        len=len-speed;

//        moveEvent(users[which]);
//            qDebug()<<endx;
//             qDebug()<<endy;
//        angle=angle+0.005*dir;
//        if(angle>=0.95){
//            dir=-1;
//        }else if(angle<0.05){
//            dir=1;
        if(users[which]->exsit==true&&users[which]->exsit_2==true){
        users[which]->move(endx-50,endy);
        if(len<=60){
             users[which]->move(-100,-100);
             if(users[which]->is_exist_worth==true){
                 now_score=now_score+users[which]->worth;
                 users[which]->is_exist_worth=false;
//                 now_score_label->setText(QString::number(now_score));
                 qDebug()<<now_score;


             }
        }
    }





//        }

painter.drawImage(target,image,source);
//        painter.translate(350,120-20);

        pen.setWidth(6);
        painter.setPen(pen);
        painter.setRenderHint(QPainter::Antialiasing,true);
        painter.drawLine(x,y,endx,endy);
        }else{
            state=0;
               users[which]->exsit=false;

        }

    default:
        break;

    }




}

void GameMainWindow::keyPressEvent(QKeyEvent *event){
    qDebug()<<event->key();
    qDebug()<<is_exist_zhadan;
    if(is_exist_zhadan==true&&state==3){

        switch (event->key()) {
        case 74:
        state=0;
        len=50;
        is_exist_zhadan=false;
          users[which]->move(-100,-100);
           users[which]->is_exist_worth=false;
        qDebug()<<"zhale";
        }
    }

    if(state==1||state==2||state==3){
       return;
    }
    switch (event->key()) {
    case 75:
    state=1;

    }


}


void GameMainWindow::moveEvent(store *p)
{
    p->move(endx,endy);
    if(len<100);
    p->move(-500,-500);
}
void GameMainWindow::logic()
{
    for(int i=0, j=0;i<placex.size();i++,j++){

            if(endx>=placex[i]&&endx<=placex[i]+100&&endy>=placey[j]&&endy<=placey[j]+100&&users[i]->exsit==true){
                qDebug()<<"抓到了";
                state=3;
                which=i;
                users[which]->exsit_2=true;



        }
    }
}
void GameMainWindow::score_update(){

//    switch (event->key()) {
//    case Qt::Key_Escape:

    QFont now_score_font;
    now_score_font.setPointSize(20);
    int score1 = now_score_label->text().toInt();

    now_score_label->setFont(now_score_font);
    now_score_label->setText(QString::number(now_score));
    now_score_label->setParent(this);
    now_score_label->setGeometry(90,-10,100,100);
    if(score1!=now_score){
        now_score_label->show();
    }

//    }
}




