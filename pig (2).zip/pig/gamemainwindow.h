#ifndef GAMEMAINWINDOW_H
#define GAMEMAINWINDOW_H

#include <QMainWindow>
//引入定时器头文件
#include <QWidget>
#include <QTimer>
#include <QLabel>
#include <QPaintEvent>
#include <QPainter>
#include <QKeyEvent>
#include <store.h>
namespace Ui {
class GameMainWindow;
}

class GameMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit GameMainWindow(QWidget *parent = nullptr);
    ~GameMainWindow();

public:
    int x=505;//钩子开始坐标
    int y=150;

    int endx=500;//钩子结束坐标
    int endy=500;

    double angle=0;//钩子转动角度

    double vx;   //速度分量（伸长是以什么速度增长）
    double vy;
    int dir = 1;

    //方向
    int state=0;//状态
//    if==0摇摆
    //if==1抓取
    //if==2收回
    double speed=0.5;
    double len=50;//钩子长度
    QLabel *now_score_label ;

    bool is_exist_zhadan;

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

     void game_CountDown();
     void animate();
     void hook_CountDown();

     void on_label_linkActivated(const QString &link);

private:

    Ui::GameMainWindow *ui;
    QTimer *gametime;
    QLabel *timelabel;
    QTimer *hooktime;
    int time;

public:
    void paintEvent(QPaintEvent *);
    void keyPressEvent(QKeyEvent *event);

    void re_paint();
    void stone_paintEvent(QPaintEvent *);
    void moveEvent(store *p);
    void score_update();
    void logic();


};

#endif // GAMEMAINWINDOW_H
