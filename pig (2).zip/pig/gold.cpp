#include "gold.h"

Gold::Gold()
{

}
