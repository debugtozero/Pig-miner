#ifndef GOLD_H
#define GOLD_H


class Gold
{
public:
    Gold();
};

#endif // GOLD_H
