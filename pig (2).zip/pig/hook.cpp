#include "hook.h"

Hook::Hook()
{

}

void Hook::paintself(QPainter *)
{
    p->drawLine(x,y,endx,endy);
}
