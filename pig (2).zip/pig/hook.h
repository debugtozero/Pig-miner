#ifndef HOOK_H
#define HOOK_H

#include <QPainter>
class Hook
{

public:



    Hook(){

    }
public:
    void paintself(QPainter *);
};

#endif // HOOK_H
