#include "line.h"
#include<QPainter>
#include<gamemainwindow.h>
Line::Line()
{

}

