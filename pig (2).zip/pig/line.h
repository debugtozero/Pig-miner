#ifndef LINE_H
#define LINE_H
#include <QPen>
#include <QPainter>
#include <QPaintEvent>
class Line
{
public:


    int x=0;//钩子开始坐标
    int y=0;

    int endx=500;//钩子结束坐标
    int endy=500;

    double angle;//钩子转动角度

    double vx;   //速度分量（伸长是以什么速度增长）
    double vy;

    int state;//状态
    int dir;//方向
    double len;//钩子长度
    int index;//抓到物品号数
    Line(){

    }
public:
    void paintEvent(QPaintEvent *);
};

#endif // LINE_H
