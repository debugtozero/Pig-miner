#ifndef LOGONBUTTON_H
#define LOGONBUTTON_H

#include <QPushButton>
#include <QDebug>
#include <QEvent>

class Loginbutton : public QPushButton
{
    Q_OBJECT
public:
    Loginbutton(QString normal,QString press = "");//构造函数
    QString normal_img;//正常路径
    QString press_img;//按下路径
    bool event(QEvent *event);
    void move1(int val);
    void move2(int val);

};

#endif // LOGONBUTTON_H
