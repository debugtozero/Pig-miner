#include "losemainwindow.h"
#include "ui_losemainwindow.h"

loseMainWindow::loseMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::loseMainWindow)
{
    ui->setupUi(this);
    QPalette pa(this->palette());
    QImage img = QImage(":/game/lose.jpg");
    img = img.scaled(this->size());
    QBrush *pic = new QBrush(img);
    pa.setBrush(QPalette::Window,*pic);
    this->setAutoFillBackground(true);
    this->setPalette(pa);
    //设置背景图
}

loseMainWindow::~loseMainWindow()
{
    delete ui;
}

void loseMainWindow::on_pushButton_clicked()
{
    close();
}
