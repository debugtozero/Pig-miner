#ifndef LOSEMAINWINDOW_H
#define LOSEMAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class loseMainWindow;
}

class loseMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit loseMainWindow(QWidget *parent = nullptr);
    ~loseMainWindow();

private slots:
    void on_pushButton_clicked();

private:
    Ui::loseMainWindow *ui;
};

#endif // LOSEMAINWINDOW_H
