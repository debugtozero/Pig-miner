#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "loginbutton.h"
#include <qmovie.h>
#include <QPushButton>
#include <QTimer>
#include <gamemainwindow.h>
#include "midmainwindow.h"
#include "midmainwindow.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QPalette pa(this->palette());

    QImage img = QImage(":/back1.jpg");
    img = img.scaled(this->size());

    QBrush *pic = new QBrush(img);
    pa.setBrush(QPalette::Window,*pic);
    this->setAutoFillBackground(true);
    this->setPalette(pa);

    //设置背景图

    //自定义按钮类
     Loginbutton *login_to_gamebutton = new Loginbutton(QString(":\start-normal-000.png"), QString(":\start-hover-000.png"));
     login_to_gamebutton->setParent(this);
     login_to_gamebutton->move(150,125);
//     connect(login_to_gamebutton,&Loginbutton::clicked,);
     //pressed 按压
     //release  释放
//     设置转场界面的定时器
        time = new QTimer(this);
        time2 = 1;


//     connect(login_to_gamebutton, &Loginbutton::released,[=](){

        QMovie *movie = new QMovie(":\R-C.gif");
        ui->label1->setMovie(movie);
        movie->start();
//         GameMainWindow *gamemainwindow = new GameMainWindow();
//         gamemainwindow->show();
//         this->hide();
//     });

//        connect(login_to_gamebutton,SIGNAL(released()),this,SLOT(begin_CountDown()));
//          connect(time,SIGNAL(timeout()),this,SLOT(time_out_thing(time)));
        //链接定时器启动与槽函数
//          connect(time,&QTimer::timeout,[=](){
//                time_out_thing();

//          });
          //链接按钮响应事件

            connect(login_to_gamebutton,&Loginbutton::released,[=](){

            MidMainWindow *midmainwindow = new MidMainWindow();
            midmainwindow->show();
            close();



//            QPalette pa(this->palette());
//            QImage img = QImage(":/game/check.jpg");
//            img = img.scaled(this->size());
//            QBrush *pic = new QBrush(img);
//            pa.setBrush(QPalette::Window,*pic);
//            this->setAutoFillBackground(true);
//            this->setPalette(pa);
//            设置转场效果

//            ui->label1->hide();
//            login_to_gamebutton->hide();
//            隐藏按钮
            //设置目标分
//            QLabel *score = new QLabel();
//            QFont ft;
//            ft.setPointSize(50);
//            score->setFont(ft);
//            score->setParent(this);
//            score->setText("600");
//            QPalette pe;
//            pe.setColor(QPalette::WindowText,Qt::white);
//            score->setPalette(pe);
//            score->setGeometry(325,175,250,250);
//            score->show();


     });



}

MainWindow::~MainWindow()
{
    delete ui;

}

//void MainWindow::begin_CountDown()
//{
//    time->start(1000);


//}
//void MainWindow:: time_out_thing()
//{
//    if(time2>0)
//    {
//        qDebug()<<time2;
//        time2--;
//    }
//    else{
//        this->close();
//        GameMainWindow *gamemainwindow = new GameMainWindow();
//        gamemainwindow->show();
//        time->stop();
//    }

//}

