#include "midmainwindow.h"
#include "ui_midmainwindow.h"
#include <QTimer>
#include "gamemainwindow.h"
#include <QDebug>
MidMainWindow::MidMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MidMainWindow)
{
    ui->setupUi(this);

    QPalette pa(this->palette());
    QImage img = QImage(":/game/check.jpg");
    img = img.scaled(this->size());
    QBrush *pic = new QBrush(img);
    pa.setBrush(QPalette::Window,*pic);
    this->setAutoFillBackground(true);
    this->setPalette(pa);
//            设置转场效果

    time = new QTimer(this);
    time2 = 1;
    QLabel *score = new QLabel();
    QFont ft;
    ft.setPointSize(50);
    score->setFont(ft);
    score->setParent(this);
    score->setText("600");
    QPalette pe;
    pe.setColor(QPalette::WindowText,Qt::white);
    score->setPalette(pe);
    score->setGeometry(325,175,250,250);
    score->show();
    connect(time,&QTimer::timeout,[=](){
          time_out_thing();

    });
    //链接按钮响应事件

    begin_CountDown();
    close();

}

MidMainWindow::~MidMainWindow()
{
    delete ui;
}
void MidMainWindow::begin_CountDown()
{
    time->start(1000);


}
void MidMainWindow:: time_out_thing()
{
    if(time2>0)
    {
        qDebug()<<time2;
        time2--;
    }
    else{
        this->close();
        GameMainWindow *gamemainwindow = new GameMainWindow();
        gamemainwindow->is_exist_zhadan=false;
        gamemainwindow->show();
        time->stop();
    }

}
