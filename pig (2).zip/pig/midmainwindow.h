#ifndef MIDMAINWINDOW_H
#define MIDMAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MidMainWindow;
}

class MidMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MidMainWindow(QWidget *parent = nullptr);
    ~MidMainWindow();

private slots:
    void begin_CountDown();//声明按钮的槽函数
    void time_out_thing();
private:
    Ui::MidMainWindow *ui;
    QTimer *time;
    int time2;
};

#endif // MIDMAINWINDOW_H
