#include "minerhook.h"

MinerHook::MinerHook()
{

}
