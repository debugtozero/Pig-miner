#include "MyButton.h"
#include <QDebug>
#include <QLabel>


MyButton::MyButton(QWidget *pu):QPushButton(pu)
{

}
void  MyButton::leaveEvent(QEvent*event)

{
     qDebug()<<"0";
     emit leaveEvent_1();
}

//重写鼠标出去时的方法
void MyButton::enterEvent(QEvent*event)

{
     qDebug()<<"1";
     emit enterEvent_1();
}

