#ifndef MYBUTTON_H
#define MYBUTTON_H

#include <QObject>
#include <QWidget>
#include<QPushButton>
#include <QLabel>

class MyButton : public QPushButton
{
    Q_OBJECT

public:
    MyButton(QWidget *pu = nullptr);

//信号
signals:
      void leaveEvent_1();//鼠标离开
      void enterEvent_1();//鼠标进入
public:
    void  leaveEvent(QEvent*event);//重写鼠标出去时的方法
    void  enterEvent(QEvent*event);


};

#endif // MYBUTTON_H
