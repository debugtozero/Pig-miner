#include "mylabel.h"

 class mylabel::public QLabel
{
    Q_OBJECT

}
