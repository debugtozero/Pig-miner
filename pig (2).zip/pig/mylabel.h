#ifndef MYLABEL_H
#define MYLABEL_H


class mylabel
{
public:
    mylabel();
};

#endif // MYLABEL_H
