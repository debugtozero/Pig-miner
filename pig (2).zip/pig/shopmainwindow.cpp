#include "shopmainwindow.h"
#include "ui_shopmainwindow.h"
#include "mybutton.h"
#include <QEvent>
#include <QObject>
#include <QWidget>
#include<QPushButton>
#include <QLabel>
#include <QDebug>
#include "loginbutton.h"
#include "gamemainwindow.h"
#include"userservice.h"
#include "QMessageBox"
#include"midmainwindow.h"
shopMainWindow::shopMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::shopMainWindow)
{
    ui->setupUi(this);
    QPalette pa(this->palette());
    QImage img = QImage(":/shop_back.jpg");
    img = img.scaled(this->size());
    QBrush *pic = new QBrush(img);
    pa.setBrush(QPalette::Window,*pic);
    this->setAutoFillBackground(true);
    this->setPalette(pa);
//file:///D:/qtcode/ikun/storebomb.png
//file:///D:/qtcode/ikun/stronger.png
    ui->label_1->hide();
    ui->label_2->hide();
    MyButton *button1 = new MyButton();
    MyButton *button2 = new MyButton();
    button1->setParent(this);
    button2->setParent(this);
    button1->move(125,225);//设置按钮位置
    button1->setFixedSize(150,150);//设置按钮的大小
    button2->move(350,225);//设置按钮位置
    button2->setFixedSize(150,150);//设置按钮的大小
    button1->show();
    button2->show();
    button1->setStyleSheet("border-image: url(:\\mineral/storebomb.jpg);");

    button2->setStyleSheet("border-image: url(:/muscle(1)(1).png);");

    b_is_clicked=false;
    connect(button1,&MyButton::enterEvent_1,this,[=]{
       ui->label_1->show();

    });
    connect(button1,&MyButton::clicked,this,[=]{
       button1->hide();
       QMessageBox::about(this,"提示","购买成功");
         a_is_clicked=true;
    });
    connect(button2,&MyButton::clicked,this,[=]{
        button2->hide();

        b_is_clicked=true;
         QMessageBox::about(this,"提示","购买成功");

     });
    connect(button1,&MyButton::leaveEvent_1,this,[=]{
       ui->label_1->hide();

    });
    connect(button2,&MyButton::enterEvent_1,this,[=]{
       ui->label_2->show();

    });
    connect(button2,&MyButton::leaveEvent_1,this,[=]{
       ui->label_2->hide();

    });
    Loginbutton *login_to_gamebutton = new Loginbutton(QString(":/game/next-normal-000.png"), QString(":/game/next-hover-000.png"));
    login_to_gamebutton->setParent(this);
    login_to_gamebutton->move(575,500);
    connect(login_to_gamebutton,&Loginbutton::released,[=](){
//        MidMainWindow *midmainwindow = new MidMainWindow();
//        midmainwindow->show();
        gamemainwindow = new GameMainWindow();
        if(b_is_clicked==true){

            gamemainwindow->speed=2;
        }else{
            gamemainwindow->speed=0.5;
        }
        if(a_is_clicked==true){

            gamemainwindow->is_exist_zhadan=true;
        }else{
            gamemainwindow->is_exist_zhadan=false;
        }
        b_is_clicked=false;
        a_is_clicked=false;
        gamemainwindow->show();
        Userservice service;

        close();

    });


}

shopMainWindow::~shopMainWindow()
{
    delete ui;
}
