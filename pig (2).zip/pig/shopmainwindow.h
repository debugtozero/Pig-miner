#ifndef SHOPMAINWINDOW_H
#define SHOPMAINWINDOW_H

#include <QMainWindow>
#include "gamemainwindow.h"
namespace Ui {
class shopMainWindow;
}

class shopMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit shopMainWindow(QWidget *parent = nullptr);
    ~shopMainWindow();
    bool a_is_clicked,b_is_clicked;
private:
    Ui::shopMainWindow *ui;
    GameMainWindow *gamemainwindow;

};

#endif // SHOPMAINWINDOW_H
