#ifndef STORE_H
#define STORE_H
#include<string>
#include<QImage>
#include<QPaintEvent>
#include <QLabel>
using namespace std;
class store:public QLabel
{
public:
    int heavy;//重量
    double place_x;//坐标x
    double place_y;//坐标y
    int width;
    int height;
    QImage img;

    int type;//物品类型
    bool exsit;//是否存在
    int worth;//价值大小
    bool exsit_2;
        bool is_exist_worth;
    store(){

    }
void paintself();

};
#endif // STORE_H

