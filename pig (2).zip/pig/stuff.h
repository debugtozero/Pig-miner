#ifndef STUFF_H
#define STUFF_H

#include "store.h"
class Stuff
{
public:
    Stuff();
};

#endif // STUFF_H
