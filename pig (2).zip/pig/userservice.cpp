#include "userservice.h"

Userservice::Userservice()
{

}


bool Userservice::if_score_achieve(int now_scores,int level){
    if(now_scores>=goal[level]){

        return true;
    }
    else{
        return false;
    }
}



