#ifndef USERSERVICE_H
#define USERSERVICE_H
#include<User.h>
#include<store.h>


class Userservice
{
public:
    Userservice();
public:
    int level=1;
    int now_score;
    int goal[6]={0,600,1500,3000,5000,100000};
    bool if_score_achieve(int now_scores,int level);


};

#endif // USERSERVICE_H
