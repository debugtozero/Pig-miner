#include "widget.h"
#include <QLabel>
#include "gamemainwindow.h"
#include "ui_gamemainwindow.h"
#include "mainwindow.h"
#include "winmainwindow.h"
#include "losemainwindow.h"
#include "shopmainwindow.h"
#include <QLabel>
#include <QMovie>
#include "userservice.h"
#include <QTimer>
#include <hook.h>
#include <QPainter>
#include "hook.h"
#include <QWidget>
#include "line.h"
#include "clawline.h"
#include "widget.h"

//int level=1;
//int now_score = 10000;
//Widget::Widget(QWidget *parent) : QWidget(parent)
//{
//    QLabel *label = new QLabel();
//    label->setText("asdas");
//    label->show();

//    label->setParent(this);
//        QMovie *movie = new QMovie(":/mineral/IMG_5124.gif");
//        label->setMovie(movie);
//        movie->start();
//        label->setGeometry(250,0,100,100);
//        label->setStyleSheet("");
//        label->setVisible(true);
//        label->setParent(this);
//        label->setStyleSheet("QLabel{background-image: url(:/worker.png);}");
//        timelabel =new QLabel("60",this);
//        QFont font =timelabel->font();
//        font.setPointSize(20);
//        timelabel->setFont(font);
//        timelabel->setGeometry(650,-20,100,100);

//        gametime =new QTimer(this);
//        gametime->start(1000);
////        connect(gametime,&QTimer::timeout,this,&GameMainWindow::game_CountDown);//绑定定时器信号与槽函数
//        Userservice service;
//        QLabel *level_window = new QLabel();
//        QFont ft;
//        ft.setPointSize(20);
//        level_window->setFont(ft);
//        level_window->setText(QString::number(level));
//        level_window->setParent(this);
//        level_window->setVisible(true);
//        level_window->setGeometry(620,20,400,100);
//        level_window->show();//关卡加载
//}
//Widget::~Widget(){

//}
//void Widget :: paintEvent(QPaintEvent *event){
//    QPainter painter(this);
//    QPen pen;
//    pen.setColor(QColor(255,0,0));
//    pen.setWidth(5);
//    painter.setPen(pen);
//    painter.drawLine(QPoint(10,10),QPoint(100,100));
//}

//void Widget::game_CountDown()
//{
//    int i = timelabel->text().toInt();
//    if(i>0){
//    i =i-1;
//    timelabel->setText(QString::number(i));

//    }
//    else{
//        Userservice service;
//        if(service.if_score_achieve(now_score,level)){
//            level++;
//            gametime->stop();
//            winMainWindow *winmainwindow = new winMainWindow();
//            winmainwindow->show();
//            close();

//        }else{
//            gametime->stop();
//            loseMainWindow *losemainwindow = new loseMainWindow();
//            losemainwindow->show();
//            close();
//        }


//    }

//}

