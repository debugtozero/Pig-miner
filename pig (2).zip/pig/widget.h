#ifndef WIDGET_H
#define WIDGET_H

#include <QPainter>
#include <QPaintEvent>
#include <QWidget>
#include <QLabel>

class Widget :public QWidget
{

    Q_OBJECT
private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

     void game_CountDown();
public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    void paintEvent(QPaintEvent *event) override;
private:


    QTimer *gametime;
    QLabel *timelabel;

};

#endif // WIDGET_H
