#include "winmainwindow.h"
#include "ui_winmainwindow.h"
#include "loginbutton.h"
#include "shopmainwindow.h"
winMainWindow::winMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::winMainWindow)
{
    ui->setupUi(this);
    QPalette pa(this->palette());
    QImage img = QImage(":/game/win.jpg");
    img = img.scaled(this->size());
    QBrush *pic = new QBrush(img);
    pa.setBrush(QPalette::Window,*pic);
    this->setAutoFillBackground(true);
    this->setPalette(pa);
    Loginbutton *login_to_gamebutton = new Loginbutton(QString(":/game/next-normal-000.png"), QString(":/game/next-hover-000.png"));
    login_to_gamebutton->setParent(this);
    login_to_gamebutton->move(325,425);
    connect(login_to_gamebutton,&Loginbutton::released,[=](){
        shopMainWindow *shopmainwindow = new shopMainWindow();
        shopmainwindow->show();
        close();

    });


}

winMainWindow::~winMainWindow()
{
    delete ui;
}
