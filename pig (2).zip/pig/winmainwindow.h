#ifndef WINMAINWINDOW_H
#define WINMAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class winMainWindow;
}

class winMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit winMainWindow(QWidget *parent = nullptr);
    ~winMainWindow();

private:
    Ui::winMainWindow *ui;
};

#endif // WINMAINWINDOW_H
